<?php

/**
* Placeholder for your own spam rules
*/
class SpamFilter
{
	public function canPost($text)
	{
		return true;
	}

}